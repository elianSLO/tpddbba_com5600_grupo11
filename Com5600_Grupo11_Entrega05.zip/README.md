# com5600_grupo11
Trabajo práctico integrador de la materia Bases de Datos Aplicada de la Universidad Nacional de La Matanza.

36756277 | Varela, Lucas Sebastián

43779349 | Pizzi, Matías Nahuel

42905229 | Módica, Elián Ariel

Link al DER:
https://drive.google.com/file/d/1uwrWhckUKhkNV3q1BU1_-nm29-MKYmjc/view?usp=sharing